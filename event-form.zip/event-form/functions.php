<?php

define( 'CHILD_DIR', get_theme_file_uri() );
define( 'PARENT_DIR', get_stylesheet_directory_uri() );

add_action( 'post_edit_form_tag' , 'post_edit_form_tag' );
function post_edit_form_tag( ) {
   echo ' enctype="multipart/form-data"';
}

// load js files in footer & style in header start
add_action('wp_enqueue_scripts', 'event_scripts');
function event_scripts() {
    wp_enqueue_script('jquery');

    wp_enqueue_script('event-main-script', PARENT_DIR . '/assets/js/custom.js', array(), '1.0.0', true );    

    /****Ajax call ****/
    wp_enqueue_script('autocomplete-search', get_stylesheet_directory_uri() . '/assets/js/autocomplete.js', 
        ['jquery', 'jquery-ui-autocomplete'], null, true);
    wp_localize_script('event-main-script', 'AjaxRequest', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'ajax_nonce' => wp_create_nonce('neweventNonce'),
    ]);
}

add_action( 'init', 'event_custom_posts' );
function event_custom_posts() {
  $labels = array(
    'name'               => _x( 'Events', 'post type general name' ),
    'singular_name'      => _x( 'Event', 'post type singular name' ),
    'add_new'            => _x( 'Add New Event', 'event' ),
    'add_new_item'       => __( 'Add New Event' ),
    'edit_item'          => __( 'Edit Event' ),
    'new_item'           => __( 'New Event' ),
    'all_items'          => __( 'All Events' ),
    'view_item'          => __( 'View Event' ),
    'search_items'       => __( 'Search Events' ),
    'not_found'          => __( 'No Events found' ),
    'not_found_in_trash' => __( 'No Events found in the Trash' ),
    'menu_name'          => 'Events'
  );
  $args = array(
    'labels'        => $labels,
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true,
  );
  register_post_type( 'task', $args ); 
}

// create a Custom post taxonomy for magazines
add_action( 'init', 'sigma_mt_taxonomies_magazines', 0 );
function sigma_mt_taxonomies_magazines(){
    register_taxonomy('event-cat', array('task'), array('hierarchical' => true,
            'labels' => array(
                'name' => __('City Categories', 'twentyseventeen'),
                'singular_name' => __('City Category', 'twentyseventeen'),
                'search_items' => __('Search City Category', 'twentyseventeen'),
                'all_items' => __('All City Categories', 'twentyseventeen'),
                'parent_item' => __('Parent City Category', 'twentyseventeen'),
                'parent_item_colon' => __('Parent City Category:', 'twentyseventeen'),
                'edit_item' => __('Edit City Category', 'twentyseventeen'),
                'update_item' => __('Refresh City Category', 'twentyseventeen'),
                'add_new_item' => __('Add City Category', 'twentyseventeen'),
                'new_item_name' => __('New City Category', 'twentyseventeen')
            ),
            'show_ui' => true,
            'rewrite' => array('slug' => 'event-cat')
        )
    );
}

//Shortcode to get event info
add_shortcode( 'featch-event-info', 'featch_event_info' );
function featch_event_info() {
    $content = '';
    $cat = get_terms('event-cat'); // you can put your custom taxonomy name as place of category.

    #echo '<pre>'; print_r($cat); exit;
    foreach ($cat as $catVal) {
        $content .= '<h2>'.$catVal->name.'</h2>';
        $postArg = array('post_type'=>'task','posts_per_page'=>-1,'order'=>'desc',
                          'tax_query' => array(
                                                array(
                                                    'taxonomy' => 'event-cat',
                                                    'field' => 'term_id',
                                                    'terms' => $catVal->term_id
                                                )
                        ));

        $getPost = new wp_query($postArg);
        global $post;
        if($getPost->have_posts()){
            $content .= '<ul>';
                while ( $getPost->have_posts()):$getPost->the_post();
                    $content .= "<li><a href='".get_permalink()."'>".$post->post_title."</a></li>";
                endwhile;
            $content .= '</ul>';
        }
    }

    return $content;
}

//Ajax call
add_action( 'wp_ajax_nopriv_post_event_info', 'post_event_info' );
add_action( 'wp_ajax_post_event_info', 'post_event_info' );
function post_event_info() {
    parse_str($_POST['data'], $arrayData);
    
    //echo '<pre>'; print_r($_FILES); exit;

    $postTitle      = sanitize_text_field( $arrayData['ename'] );
    $eventDate      = sanitize_text_field( $arrayData['edate'] );
    $postDesc       = sanitize_text_field( $arrayData['content'] );
    $city           = sanitize_text_field( $arrayData['city'] );
    $featuredImage  = sanitize_text_field( $arrayData['image'] );
    $postType       = sanitize_text_field( $arrayData['post_type'] );
    $wpNonce        = sanitize_text_field( $arrayData['_wpnonce'] );
    $cat_id         = sanitize_text_field( $arrayData['event_category'] );

    // Check that the nonce was set and valid
    if( !wp_verify_nonce($wpNonce, 'event-frontend-post') ) {
        echo 'Did not save because your form seemed to be invalid. Sorry';
        exit;
    }

    // Do some minor form validation to make sure there is content
    if (strlen($postTitle) < 3) {
        echo 'Please enter a title. Titles must be at least three characters long.';
        exit;
    }
    if (strlen($postDesc) < 50) {
        echo 'Please enter content more than 50 characters in length';
        exit;
    }

    // Add the content of the form to $post as an array
    $args = array(
        'post_title'    => $postTitle,
        'post_content'  => $postDesc,
        'post_type'     => $postType,
        'post_author'   => 1,
        'post_status'   => 'draft',
    );

    $post_id = wp_insert_post( $args );

    if($post_id!=0) {

        $cat_ids = array($cat_id);  
        $cat_ids = array_map( 'intval', $cat_ids );
        $cat_ids = array_unique( $cat_ids );

        $term_taxonomy_ids = wp_set_object_terms($post_id, $cat_ids, 'event-cat' );
    
        if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );


        //if ( isset($featuredImage) ) {
            $uploaddir = wp_upload_dir();
            $file = $_FILES[$featuredImage];
            $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );

            move_uploaded_file( $file['tmp_name'] , $uploadfile );
            $filename = basename( $uploadfile );

            $wp_filetype = wp_check_filetype(basename($filename), null );

            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit',
                'menu_order' => $_i + 1000
            );
            $attach_id = wp_insert_attachment( $attachment, $uploadfile );
        //}


        $uploadedfile = $_FILES['image'];
        $upload_overrides = array( 'event_form' => false );
        $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
        add_post_meta($post_id, 'wpcf-event-image', $movefile['url'] );
    }
    echo 'Event is created.';
    exit;;
}