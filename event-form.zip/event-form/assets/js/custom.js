// Create a function to pick up the action
jQuery(document).ready(function($) {
    $("body").click(function(e) {
        if (e.target.class != "form") {
            $('.resultData ul').remove();
            $('.resultData').hide();
            $('.resultData').css('display', 'none');
        }
    });
    $('#submitData').click(function(event){
        event.preventDefault(); // prevent default behaviour of link click
        var form = $('#form');
        var errors = 0;
        $("#form :input").map(function(){
             if( !$(this).val() ) {
                  $(this).parents('.field').addClass('warning');
                  errors++;
            } else if ($(this).val()) {
                  $(this).parents('.field').removeClass('warning');
            }   
        });
        $.ajax({
            type : "POST",
            dataType: "text",
            url : AjaxRequest.ajax_url,
            data : {
                action: "post_event_info",
                data:   form.serialize(), // serializes the form's elements.
            },
            beforeSend: function() {
                $('html, body').css("cursor", "wait");
                $('button').css("cursor", "wait");
                $('.resultData').hide();
                $('.resultData').css('display', 'none');
            },
            success: function(response) {
                //alert(response);
                $("html,body").animate({
                    scrollTop: $(".resultData").offset().top
                }, 1000, function(){
                    $('html, body').css("cursor", "pointer");
                    $('button').css("cursor", "pointer");
                    $('.resultData').show();
                    $('.resultData').css('display', 'block');
                    $('.resultData').html(response);
                });
            }
        });

    });
});