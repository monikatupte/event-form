<?php
/**
 * Template Name: Event Form Layout
 * Created By: Admin
 * Created at: 09 Jully 2021
 */

get_header();

?>


<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <article>
            <div class="event-form entry-content">
                <h3>Event Form</h3>
                <div class="resultData" style="display: none;"></div>
                <div class="form">
                    <form enctype="multipart/form-data" method="post" id="form" class="wp-form">
                        <div class="ename-field">
                            <div class="field">
                                <label for="ename">Event Name</label>
                                <input type="text" id="ename" name="ename">
                            </div>
                        </div>

                        <div class="desc-field">
                            <label for="content">Description</label>
                            <!-- Birth Day -->
                            <textarea id="content" tabindex="3" name="content" cols="50" rows="6"></textarea>
                        </div>

                        <div class="date-field">
                            <label for="edate">Event Date</label>
                            <!-- Birth Day -->
                            <input type="date" id="edate" name="edate">
                        </div>

                        <div class="city-field">
                            <div class="field">
                                <label for="city">City</label>
                                <?php
                                     $terms = get_terms("event-cat",'order_by=count&hide_empty=0');
                                    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                                        echo "<select name='event_category'>";
                                            echo "<option selected='selected'> Select </option>";
                                            foreach ( $terms as $term ) {
                                                echo "<option value='".$term->term_id."'>" . $term->name . "</option>";
                                            }
                                        echo "</select>";
                                    }
                                ?>
                            </div>
                        </div>

                        <div class="image-field">
                            <div class="field">
                                <label for="image">Event Photo</label>
                                <input type="file" id="image" name="upload_image">
                            </div>
                        </div>

                        <input type="hidden" name="post_type" id="post_type" value="task" />

                        <?php wp_nonce_field( 'event-frontend-post' ); ?>

                        <div class="button-field">
                            <button id="submitData">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </article>
    </main>
</div>

<style type="text/css">
    .resultData {
        display: block;
        background: #6fca6f;
        padding: 20px;
        color: #fff;
        font-weight: bold;
    }
    .event-form.entry-content {
        width: 70%;
        margin: 0 auto;
    }
</style>

<?php get_footer(); ?>